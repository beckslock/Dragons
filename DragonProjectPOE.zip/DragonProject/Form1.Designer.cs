﻿namespace DragonProject
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            button1 = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            groupBox3 = new GroupBox();
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            groupBox2 = new GroupBox();
            button2 = new Button();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            groupBox4 = new GroupBox();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            radioButton8 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton5 = new RadioButton();
            button3 = new Button();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox2.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(64, 11);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(287, 341);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Player 1";
            // 
            // button1
            // 
            button1.BackColor = Color.LightGray;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(20, 299);
            button1.Name = "button1";
            button1.Size = new Size(237, 23);
            button1.TabIndex = 5;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox2
            // 
            textBox2.BorderStyle = BorderStyle.FixedSingle;
            textBox2.Font = new Font("Segoe UI", 6F, FontStyle.Bold);
            textBox2.Location = new Point(96, 74);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(161, 18);
            textBox2.TabIndex = 4;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Segoe UI", 6F, FontStyle.Bold);
            textBox1.Location = new Point(96, 45);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(161, 18);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(6, 77);
            label2.Name = "label2";
            label2.Size = new Size(85, 15);
            label2.TabIndex = 2;
            label2.Text = "Dragon Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(6, 48);
            label1.Name = "label1";
            label1.Size = new Size(77, 15);
            label1.TabIndex = 1;
            label1.Text = "Player Name:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(pictureBox1);
            groupBox3.Controls.Add(pictureBox4);
            groupBox3.Controls.Add(pictureBox3);
            groupBox3.Controls.Add(pictureBox2);
            groupBox3.Controls.Add(radioButton4);
            groupBox3.Controls.Add(radioButton3);
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(radioButton1);
            groupBox3.Location = new Point(20, 128);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(237, 154);
            groupBox3.TabIndex = 0;
            groupBox3.TabStop = false;
            groupBox3.Text = "Dragon Type";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Location = new Point(136, 31);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(75, 104);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = (Image)resources.GetObject("pictureBox4.BackgroundImage");
            pictureBox4.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox4.Location = new Point(136, 33);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(67, 102);
            pictureBox4.TabIndex = 6;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox3.Location = new Point(137, 35);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(66, 100);
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Location = new Point(136, 36);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 99);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.ForeColor = Color.FromArgb(0, 192, 0);
            radioButton4.Location = new Point(6, 110);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(98, 19);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "Earth Dragon";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.ForeColor = Color.Orange;
            radioButton3.Location = new Point(6, 85);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(98, 19);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "Wind Dragon";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.ForeColor = Color.CornflowerBlue;
            radioButton2.Location = new Point(6, 60);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(86, 19);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Ice Dragon";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.ForeColor = Color.Firebrick;
            radioButton1.Location = new Point(6, 35);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(90, 19);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Fire Dragon";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(textBox4);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(groupBox4);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(386, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(290, 341);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Player 2";
            // 
            // button2
            // 
            button2.BackColor = Color.LightGray;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(22, 299);
            button2.Name = "button2";
            button2.Size = new Size(239, 23);
            button2.TabIndex = 7;
            button2.Text = "Save";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // textBox4
            // 
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Font = new Font("Segoe UI", 6F, FontStyle.Bold);
            textBox4.Location = new Point(98, 74);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(163, 18);
            textBox4.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Font = new Font("Segoe UI", 6F, FontStyle.Bold);
            textBox3.Location = new Point(98, 49);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(163, 18);
            textBox3.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(6, 74);
            label4.Name = "label4";
            label4.Size = new Size(85, 15);
            label4.TabIndex = 2;
            label4.Text = "Dragon Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(6, 48);
            label3.Name = "label3";
            label3.Size = new Size(77, 15);
            label3.TabIndex = 1;
            label3.Text = "Player Name:";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(pictureBox8);
            groupBox4.Controls.Add(pictureBox7);
            groupBox4.Controls.Add(pictureBox6);
            groupBox4.Controls.Add(pictureBox5);
            groupBox4.Controls.Add(radioButton8);
            groupBox4.Controls.Add(radioButton7);
            groupBox4.Controls.Add(radioButton6);
            groupBox4.Controls.Add(radioButton5);
            groupBox4.Location = new Point(22, 128);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(239, 154);
            groupBox4.TabIndex = 0;
            groupBox4.TabStop = false;
            groupBox4.Text = "Dragon Type";
            // 
            // pictureBox8
            // 
            pictureBox8.BackgroundImage = (Image)resources.GetObject("pictureBox8.BackgroundImage");
            pictureBox8.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox8.Location = new Point(141, 28);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(75, 106);
            pictureBox8.TabIndex = 7;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackgroundImage = (Image)resources.GetObject("pictureBox7.BackgroundImage");
            pictureBox7.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox7.Location = new Point(141, 29);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(75, 105);
            pictureBox7.TabIndex = 6;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImage = (Image)resources.GetObject("pictureBox6.BackgroundImage");
            pictureBox6.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox6.Location = new Point(141, 29);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(75, 105);
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImage = (Image)resources.GetObject("pictureBox5.BackgroundImage");
            pictureBox5.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox5.Location = new Point(141, 29);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(75, 105);
            pictureBox5.TabIndex = 4;
            pictureBox5.TabStop = false;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.ForeColor = Color.FromArgb(0, 192, 0);
            radioButton8.Location = new Point(6, 110);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(98, 19);
            radioButton8.TabIndex = 3;
            radioButton8.TabStop = true;
            radioButton8.Text = "Earth Dragon";
            radioButton8.UseVisualStyleBackColor = true;
            radioButton8.CheckedChanged += radioButton8_CheckedChanged;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.ForeColor = Color.Orange;
            radioButton7.Location = new Point(6, 85);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(98, 19);
            radioButton7.TabIndex = 2;
            radioButton7.TabStop = true;
            radioButton7.Text = "Wind Dragon";
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.CheckedChanged += radioButton7_CheckedChanged;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.ForeColor = Color.CornflowerBlue;
            radioButton6.Location = new Point(6, 60);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(86, 19);
            radioButton6.TabIndex = 1;
            radioButton6.TabStop = true;
            radioButton6.Text = "Ice Dragon";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.ForeColor = Color.Firebrick;
            radioButton5.Location = new Point(6, 35);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(90, 19);
            radioButton5.TabIndex = 0;
            radioButton5.TabStop = true;
            radioButton5.Text = "Fire Dragon";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioButton5_CheckedChanged;
            // 
            // button3
            // 
            button3.BackColor = Color.LightGray;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Location = new Point(64, 369);
            button3.Name = "button3";
            button3.Size = new Size(612, 43);
            button3.TabIndex = 2;
            button3.Text = "Start Game";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(699, 9);
            label5.Name = "label5";
            label5.Size = new Size(82, 15);
            label5.TabIndex = 3;
            label5.Text = "Dragon Stats:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Firebrick;
            label6.Location = new Point(699, 41);
            label6.Name = "label6";
            label6.Size = new Size(69, 15);
            label6.TabIndex = 4;
            label6.Text = "Fire Dragon";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(699, 56);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 5;
            label7.Text = "20 HP";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(699, 71);
            label8.Name = "label8";
            label8.Size = new Size(97, 15);
            label8.TabIndex = 6;
            label8.Text = "5 Attack Damage";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(699, 86);
            label9.Name = "label9";
            label9.Size = new Size(143, 15);
            label9.TabIndex = 7;
            label9.Text = "12 Special Attack Damage";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(699, 101);
            label10.Name = "label10";
            label10.Size = new Size(92, 15);
            label10.TabIndex = 8;
            label10.Text = "4 Block Damage";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.CornflowerBlue;
            label11.Location = new Point(699, 140);
            label11.Name = "label11";
            label11.Size = new Size(66, 15);
            label11.TabIndex = 9;
            label11.Text = "Ice Dragon";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(699, 155);
            label12.Name = "label12";
            label12.Size = new Size(38, 15);
            label12.TabIndex = 10;
            label12.Text = "30 HP";
            label12.Click += label12_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(699, 170);
            label13.Name = "label13";
            label13.Size = new Size(97, 15);
            label13.TabIndex = 11;
            label13.Text = "4 Attack Damage";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(699, 185);
            label14.Name = "label14";
            label14.Size = new Size(137, 15);
            label14.TabIndex = 12;
            label14.Text = "9 Special Attack Damage";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(699, 200);
            label15.Name = "label15";
            label15.Size = new Size(92, 15);
            label15.TabIndex = 13;
            label15.Text = "5 Block Damage";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.Orange;
            label16.Location = new Point(699, 238);
            label16.Name = "label16";
            label16.Size = new Size(79, 15);
            label16.TabIndex = 14;
            label16.Text = "Wind Dragon";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(699, 253);
            label17.Name = "label17";
            label17.Size = new Size(38, 15);
            label17.TabIndex = 4;
            label17.Text = "40 HP";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(699, 268);
            label18.Name = "label18";
            label18.Size = new Size(97, 15);
            label18.TabIndex = 15;
            label18.Text = "3 Attack Damage";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(699, 283);
            label19.Name = "label19";
            label19.Size = new Size(137, 15);
            label19.TabIndex = 16;
            label19.Text = "7 Special Attack Damage";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(699, 298);
            label20.Name = "label20";
            label20.Size = new Size(92, 15);
            label20.TabIndex = 17;
            label20.Text = "5 Block Damage";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.FromArgb(0, 192, 0);
            label21.Location = new Point(699, 337);
            label21.Name = "label21";
            label21.Size = new Size(77, 15);
            label21.TabIndex = 18;
            label21.Text = "Earth Dragon";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(699, 352);
            label22.Name = "label22";
            label22.Size = new Size(38, 15);
            label22.TabIndex = 19;
            label22.Text = "50 HP";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(699, 367);
            label23.Name = "label23";
            label23.Size = new Size(97, 15);
            label23.TabIndex = 20;
            label23.Text = "2 Attack Damage";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(699, 382);
            label24.Name = "label24";
            label24.Size = new Size(137, 15);
            label24.TabIndex = 21;
            label24.Text = "5 Special Attack Damage";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(699, 397);
            label25.Name = "label25";
            label25.Size = new Size(92, 15);
            label25.TabIndex = 22;
            label25.Text = "6 Block Damage";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(871, 450);
            Controls.Add(label25);
            Controls.Add(label24);
            Controls.Add(label23);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(button3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Dragon Battle!";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private GroupBox groupBox3;
        private GroupBox groupBox2;
        private TextBox textBox3;
        private Label label4;
        private Label label3;
        private GroupBox groupBox4;
        private Button button1;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Button button2;
        private TextBox textBox4;
        private RadioButton radioButton8;
        private RadioButton radioButton7;
        private RadioButton radioButton6;
        private RadioButton radioButton5;
        private Button button3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
    }
}
